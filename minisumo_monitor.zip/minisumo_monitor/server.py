"""Servidor de monitoreo mini-Sumo: recibe telemetria por WiFi (HTTP/JSON),
la guarda en SQLite y sirve la interfaz web del dashboard. Uso: python server.py"""
import os, sqlite3, time, csv, io
from flask import Flask, request, jsonify, Response, g

app = Flask(__name__, static_folder="static", static_url_path="")
DB = os.environ.get("DB_PATH", "sumo.db")
COLS = ["t", "vl", "vr", "x", "y", "yaw", "batt", "state"]

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()

def init():
    with sqlite3.connect(DB) as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS combats(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,
            started_at REAL, ended_at REAL);
        CREATE TABLE IF NOT EXISTS samples(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            combat_id INTEGER REFERENCES combats(id),
            t INTEGER, vl REAL, vr REAL, x REAL, y REAL,
            yaw REAL, batt REAL, state TEXT);
        CREATE INDEX IF NOT EXISTS ix_s ON samples(combat_id, id);""")

def active():
    return db().execute("SELECT * FROM combats WHERE ended_at IS NULL").fetchone()

@app.get("/")
def home():
    return app.send_static_file("index.html")

@app.post("/api/combats/start")
def start():
    d = db(); now = time.time()
    d.execute("UPDATE combats SET ended_at=? WHERE ended_at IS NULL", (now,))
    name = (request.get_json(silent=True) or {}).get("name") or time.strftime("Combate %d/%m %H:%M")
    cur = d.execute("INSERT INTO combats(name, started_at) VALUES(?,?)", (name, now))
    d.commit()
    print(f"[SERVIDOR] -> ¡Combate iniciado! ID: {cur.lastrowid} ({name})")
    return jsonify(id=cur.lastrowid, name=name)

@app.post("/api/combats/stop")
def stop():
    d = db()
    d.execute("UPDATE combats SET ended_at=? WHERE ended_at IS NULL", (time.time(),))
    d.commit()
    print("[SERVIDOR] -> Combate finalizado.")
    return jsonify(ok=True)

@app.get("/api/combats")
def combats():
    rows = db().execute("""SELECT c.*, (SELECT COUNT(*) FROM samples s WHERE s.combat_id=c.id) AS n
                            FROM combats c ORDER BY c.id DESC""").fetchall()
    return jsonify([dict(r) for r in rows])

@app.post("/api/telemetry")
def telemetry():
    d = db()
    c = active()
    
    # Crea un combate automáticamente si no hay ninguno activo para evitar errores
    if not c:
        now = time.time()
        name = time.strftime("Combate automático %d/%m %H:%M")
        cur = d.execute("INSERT INTO combats(name, started_at) VALUES(?,?)", (name, now))
        d.commit()
        combat_id = cur.lastrowid
        print(f"[SERVIDOR] -> Combate automático creado. ID: {combat_id} ({name})")
        c = d.execute("SELECT * FROM combats WHERE id=?", (combat_id,)).fetchone()
        
    samples = (request.get_json(silent=True) or {}).get("samples", [])
    d.executemany(
        "INSERT INTO samples(combat_id,t,vl,vr,x,y,yaw,batt,state) VALUES(?,?,?,?,?,?,?,?,?)",
        [(c["id"], *[s.get(k) for k in COLS]) for s in samples])
    d.commit()
    
    print(f"[SERVIDOR] -> Telemetría guardada: {len(samples)} muestras para el combate ID {c['id']} [HTTP 200]")
    return jsonify(ok=True, stored=len(samples), combat=c["id"])

@app.get("/api/combats/<int:cid>/samples")
def samples(cid):
    after = request.args.get("after", 0, type=int)
    rows = db().execute("SELECT * FROM samples WHERE combat_id=? AND id>? ORDER BY id",
                        (cid, after)).fetchall()
    return jsonify([dict(r) for r in rows])

@app.get("/api/combats/<int:cid>/export.csv")
def export_csv(cid):
    rows = db().execute("SELECT t,vl,vr,x,y,yaw,batt,state FROM samples WHERE combat_id=? ORDER BY id",
                        (cid,)).fetchall()
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["t_ms", "vel_izq_cm_s", "vel_der_cm_s", "x_cm", "y_cm", "yaw_deg", "bateria_V", "estado"])
    w.writerows([tuple(r) for r in rows])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=combate_{cid}.csv"})

init()  

if __name__ == "__main__":
    # threaded=True permite atender múltiples peticiones concurrentes (muy importante para alta frecuencia)
    app.run(host="0.0.0.0", port=5000, threaded=True)