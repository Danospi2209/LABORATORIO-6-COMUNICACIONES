"""Simula al robot (sin hardware): python simulate.py [http://localhost:5000]"""
import json, math, sys, time, urllib.request
base = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:5000"
def post(path, body):
    r = urllib.request.Request(base + path, json.dumps(body).encode(), {"Content-Type": "application/json"})
    return urllib.request.urlopen(r).read()
post("/api/combats/start", {"name": "Simulacion"})
t = x = y = 0.0
for _ in range(60):                       # 60 bloques de 1 s
    block = []
    for _ in range(10):                   # 10 muestras por bloque (10 Hz)
        t += 0.1
        vl, vr = 30 + 10 * math.sin(t), 30 + 10 * math.cos(t)
        yaw = (t * 20) % 360
        x += (vl + vr) / 2 * 0.1 * math.cos(math.radians(yaw))
        y += (vl + vr) / 2 * 0.1 * math.sin(math.radians(yaw))
        block.append(dict(t=int(t * 1000), vl=round(vl, 1), vr=round(vr, 1), x=round(x, 1),
                          y=round(y, 1), yaw=round(yaw, 1), batt=round(8.2 - t / 400, 2), state="avanzando"))
    post("/api/telemetry", {"samples": block}); time.sleep(1)
post("/api/combats/stop", {})