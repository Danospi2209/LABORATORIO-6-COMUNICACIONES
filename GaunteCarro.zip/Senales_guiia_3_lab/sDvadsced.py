import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import serial
import serial.tools.list_ports


class RobotControllerApp:

  def __init__(self, root):
    self.root = root
    self.root.title(
        "ESP32 Robot Controller & Telemetry (Real-Time + Estado MPU)"
    )
    self.root.geometry("1000x900")

    self.ser = None
    self.is_connected = False
    self.running = False

    # Cola y estructuras de datos optimizadas
    self.data_queue = queue.Queue()
    self.max_points = 60

    self.time_data = []
    self.pos_left_data = []
    self.pos_right_data = []
    self.gz_raw_data = []
    self.gz_filt_data = []

    self.create_widgets()

  def create_widgets(self):
    # --- 1. Marco de Conexión y Estado MPU ---
    conn_frame = ttk.LabelFrame(
        self.root, text="Conexión y Estado del Sensor"
    )
    conn_frame.pack(fill="x", padx=10, pady=5)

    ttk.Label(conn_frame, text="Puerto:").pack(side="left", padx=5)
    self.port_combo = ttk.Combobox(conn_frame, width=12)
    self.port_combo.pack(side="left", padx=5)
    self.update_ports()

    ttk.Button(
        conn_frame, text="Actualizar", command=self.update_ports
    ).pack(side="left", padx=2)

    self.btn_connect = ttk.Button(
        conn_frame, text="Conectar", command=self.toggle_connection
    )
    self.btn_connect.pack(side="left", padx=5)

    # Cuadro de texto / Indicador del estado de la MPU
    self.mpu_status_var = tk.StringVar(
        value="MPU Estado: Desconectado / Sin verificar"
    )
    self.mpu_label = ttk.Label(
        conn_frame,
        textvariable=self.mpu_status_var,
        font=("Arial", 10, "bold"),
        foreground="gray",
    )
    self.mpu_label.pack(side="left", padx=15)

    # --- 2. Marco de Control y Filtros ---
    control_frame = ttk.LabelFrame(self.root, text="Control Manual y Filtros")
    control_frame.pack(fill="x", padx=10, pady=5)

    btn_w = ttk.Button(
        control_frame,
        text="AVANZAR (W150)",
        command=lambda: self.send_cmd("W150"),
    )
    btn_w.grid(row=0, column=1, padx=5, pady=5)

    btn_a = ttk.Button(
        control_frame, text="IZQ (A150)", command=lambda: self.send_cmd("A150")
    )
    btn_a.grid(row=1, column=0, padx=5, pady=5)

    btn_stop = ttk.Button(
        control_frame, text="STOP", command=lambda: self.send_cmd("STOP")
    )
    btn_stop.grid(row=1, column=1, padx=5, pady=5)

    btn_d = ttk.Button(
        control_frame, text="DER (D150)", command=lambda: self.send_cmd("D150")
    )
    btn_d.grid(row=1, column=2, padx=5, pady=5)

    btn_s = ttk.Button(
        control_frame,
        text="RETROCEDER (S150)",
        command=lambda: self.send_cmd("S150"),
    )
    btn_s.grid(row=2, column=1, padx=5, pady=5)

    filter_frame = ttk.Frame(control_frame)
    filter_frame.grid(row=0, column=3, rowspan=3, padx=20)

    ttk.Button(
        filter_frame, text="RESET", command=lambda: self.send_cmd("RESET")
    ).pack(fill="x", pady=2)
    ttk.Button(
        filter_frame,
        text="Sin Filtro (NOFILT)",
        command=lambda: self.send_cmd("NOFILT"),
    ).pack(fill="x", pady=2)
    ttk.Button(
        filter_frame, text="Filtro FIR", command=lambda: self.send_cmd("FIR")
    ).pack(fill="x", pady=2)
    ttk.Button(
        filter_frame, text="Filtro IIR", command=lambda: self.send_cmd("IIR")
    ).pack(fill="x", pady=2)

    # --- 3. Marco de Gráficas (4 Subplots) ---
    plot_frame = ttk.LabelFrame(self.root, text="Telemetría en Vivo (Tiempo Real)")
    plot_frame.pack(fill="both", expand=True, padx=10, pady=5)

    self.fig, (self.ax1, self.ax2, self.ax3, self.ax4) = plt.subplots(
        4, 1, figsize=(7, 5.5), dpi=100
    )

    (self.line_pos_left,) = self.ax1.plot([], [], label="Pos. Izq (cm)", color="purple")
    self.ax1.legend(loc="upper left", fontsize="small")
    self.ax1.set_ylabel("Izq")
    self.ax1.grid(True)

    (self.line_pos_right,) = self.ax2.plot([], [], label="Pos. Der (cm)", color="orange")
    self.ax2.legend(loc="upper left", fontsize="small")
    self.ax2.set_ylabel("Der")
    self.ax2.grid(True)

    (self.line_raw,) = self.ax3.plot([], [], label="Gz Raw (°/s)", color="red")
    self.ax3.legend(loc="upper left", fontsize="small")
    self.ax3.set_ylabel("Raw")
    self.ax3.grid(True)

    (self.line_filt,) = self.ax4.plot([], [], label="Gz Filt (°/s)", color="blue")
    self.ax4.legend(loc="upper left", fontsize="small")
    self.ax4.set_xlabel("Tiempo (s)")
    self.ax4.set_ylabel("Filt")
    self.ax4.grid(True)

    self.fig.tight_layout()

    self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
    self.canvas.get_tk_widget().pack(fill="both", expand=True)

  def update_ports(self):
    ports = [port.device for port in serial.tools.list_ports.comports()]
    self.port_combo["values"] = ports
    if ports:
      self.port_combo.current(0)

  def toggle_connection(self):
    if not self.is_connected:
      port = self.port_combo.get()
      if not port:
        messagebox.showerror("Error", "Selecciona un puerto COM.")
        return
      try:
        self.ser = serial.Serial(port, 115200, timeout=0.01)
        self.is_connected = True
        self.btn_connect.config(text="Desconectar")
        self.running = True

        self.thread = threading.Thread(target=self.read_serial, daemon=True)
        self.thread.start()
        self.root.after(33, self.process_data_periodic)

        # Dar un respiro de 500ms y pedir el estado de la MPU explícitamente al ESP32
        self.root.after(500, lambda: self.send_cmd("STATUS"))

        messagebox.showinfo("Éxito", f"Conectado exitosamente a {port}")
      except Exception as e:
        messagebox.showerror("Error", f"No se pudo conectar: {e}")
    else:
      self.running = False
      if self.ser and self.ser.is_open:
        self.ser.close()
      self.is_connected = False
      self.btn_connect.config(text="Conectar")
      self.mpu_status_var.set("MPU Estado: Desconectado")
      self.mpu_label.config(foreground="gray")

  def send_cmd(self, cmd):
    if self.is_connected and self.ser and self.ser.is_open:
      full_cmd = cmd + "\n"
      self.ser.write(full_cmd.encode("utf-8"))
    else:
      messagebox.showwarning("Aviso", "No estás conectado.")

  def read_serial(self):
    while self.running:
      try:
        if self.ser and self.ser.in_waiting:
          line = self.ser.readline().decode("utf-8", errors="ignore").strip()
          if line:
            # Capturar mensajes de texto del ESP32 relacionados con la MPU
            if "OK:" in line or "ERROR:" in line or "MPU6050" in line:
              self.root.after(0, lambda msg=line: self.update_mpu_status(msg))

            # Procesar telemetría CSV de 8 columnas
            parts = line.split(",")
            if len(parts) == 8:
              try:
                t = float(parts[0])
                gr = float(parts[1])
                gf = float(parts[2])
                pos_l = float(parts[6])
                pos_r = float(parts[7])

                if self.data_queue.qsize() > 5:
                  try:
                    self.data_queue.get_nowait()
                  except queue.Empty:
                    pass

                self.data_queue.put((t, pos_l, pos_r, gr, gf))
              except ValueError:
                pass  # Ignorar errores de conversión si llega texto combinado
      except Exception:
        time.sleep(0.01)

  def update_mpu_status(self, msg):
    """Actualiza dinámicamente el cuadro de texto del estado MPU"""
    self.mpu_status_var.set(f"Estado: {msg}")
    if "OK" in msg or "éxito" in msg.lower():
      self.mpu_label.config(foreground="green")
    else:
      self.mpu_label.config(foreground="red")

  def process_data_periodic(self):
    if not self.running:
      return

    updated = False
    while not self.data_queue.empty():
      t, pos_l, pos_r, gr, gf = self.data_queue.get()
      self.time_data.append(t)
      self.pos_left_data.append(pos_l)
      self.pos_right_data.append(pos_r)
      self.gz_raw_data.append(gr)
      self.gz_filt_data.append(gf)
      updated = True

      if len(self.time_data) > self.max_points:
        self.time_data.pop(0)
        self.pos_left_data.pop(0)
        self.pos_right_data.pop(0)
        self.gz_raw_data.pop(0)
        self.gz_filt_data.pop(0)

    if updated and len(self.time_data) > 0:
      self.line_pos_left.set_data(self.time_data, self.pos_left_data)
      self.ax1.relim()
      self.ax1.autoscale_view()

      self.line_pos_right.set_data(self.time_data, self.pos_right_data)
      self.ax2.relim()
      self.ax2.autoscale_view()

      self.line_raw.set_data(self.time_data, self.gz_raw_data)
      self.ax3.relim()
      self.ax3.autoscale_view()

      self.line_filt.set_data(self.time_data, self.gz_filt_data)
      self.ax4.relim()
      self.ax4.autoscale_view()

      self.canvas.draw()

    self.root.after(33, self.process_data_periodic)


if __name__ == "__main__":
  root = tk.Tk()
  app = RobotControllerApp(root)
  root.mainloop()
