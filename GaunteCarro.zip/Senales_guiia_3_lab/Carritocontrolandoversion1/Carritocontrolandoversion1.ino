#include <Arduino.h>

// ==========================================
// PINES (Lado izquierdo de la ESP32)
// ==========================================
const uint8_t PIN_ENC_1 = 32; // Encoder 1
const uint8_t PIN_ENC_2 = 33; // Encoder 2

const uint8_t PIN_PWM_1 = 25; // Motor 1 PWM
const uint8_t PIN_DIR_1 = 26; // Motor 1 Dirección

const uint8_t PIN_PWM_2 = 27; // Motor 2 PWM
const uint8_t PIN_DIR_2 = 13; // Motor 2 Dirección

// ==========================================
// PARÁMETROS DEL SISTEMA Y PID DISCRETO
// ==========================================
const uint16_t PULSOS_POR_REVOLUCION = 374; 
const unsigned long INTERVALO_MUESTREO_MS = 20; // 50 Hz (Ts = 0.02s)

// Variables de conteo de pulsos
volatile long contadorPulsos1 = 0;
volatile long contadorPulsos2 = 0;

// Variables de velocidad
volatile float referenciaV1 = 0.0;
volatile float referenciaV2 = 0.0;
float rpm1 = 0.0;
float rpm2 = 0.0;

// Ganancias del PID (Kp, Ki, Kd)
float Kp = 19794.8496;
float Ki = 40651.2327;
float Kd = 2409.7429;

// Variables de control Motor 1
float e1 = 0, e1_prev1 = 0, e1_prev2 = 0;
float u1 = 0, u1_prev = 0;

// Variables de control Motor 2
float e2 = 0, e2_prev1 = 0, e2_prev2 = 0;
float u2 = 0, u2_prev = 0;

// Declaración de funciones de interrupción
void IRAM_ATTR isrEncoder1() { contadorPulsos1++; }
void IRAM_ATTR isrEncoder2() { contadorPulsos2++; }

void setup() {
  Serial.begin(115200);
  
  // Configuración de pines
  pinMode(PIN_ENC_1, INPUT_PULLUP);
  pinMode(PIN_ENC_2, INPUT_PULLUP);
  pinMode(PIN_PWM_1, OUTPUT);
  pinMode(PIN_DIR_1, OUTPUT);
  pinMode(PIN_PWM_2, OUTPUT);
  pinMode(PIN_DIR_2, OUTPUT);

  digitalWrite(PIN_DIR_1, HIGH);
  digitalWrite(PIN_DIR_2, HIGH);

  attachInterrupt(digitalPinToInterrupt(PIN_ENC_1), isrEncoder1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_2), isrEncoder2, CHANGE);
  
  Serial.println("Sistema Serial USB Iniciado correctamente.");
}

void loop() {
  static unsigned long tiempoAnteriorControl = 0;
  static unsigned long tiempoAnteriorEnvio = 0;
  unsigned long tiempoActual = millis();

  // --- 1. RECEPCIÓN DE COMANDOS DESDE PYTHON (Puerto Serial USB) ---
  static char bufferSerial[32];
  static byte idx = 0;
  static boolean enProgreso = false;

  while (Serial.available() > 0) {
    char c = Serial.read();
    if (enProgreso) {
      if (c != '>') {
        if (idx < sizeof(bufferSerial) - 1) {
          bufferSerial[idx++] = c;
        }
      } else {
        bufferSerial[idx] = '\0';
        enProgreso = false;
        idx = 0;

        // Decodificar trama <V,ref1,ref2>
        if (bufferSerial[0] == 'V') {
          char* token = strtok(bufferSerial, ",");
          token = strtok(NULL, ",");
          if (token != NULL) referenciaV1 = atof(token);
          token = strtok(NULL, ",");
          if (token != NULL) referenciaV2 = atof(token);
        }
      }
    } else if (c == '<') {
      enProgreso = true;
      idx = 0;
    }
  }

  // --- 2. LOOP DE CONTROL PID CADA 20ms (50 Hz) ---
  if (tiempoActual - tiempoAnteriorControl >= INTERVALO_MUESTREO_MS) {
    tiempoAnteriorControl = tiempoActual;

    // Sección crítica corta para leer contadores de encoders
    noInterrupts();
    long pulsos1 = contadorPulsos1;
    long pulsos2 = contadorPulsos2;
    contadorPulsos1 = 0;
    contadorPulsos2 = 0;
    interrupts();

    // Calcular RPM actuales
    rpm1 = ((float)pulsos1 / PULSOS_POR_REVOLUCION) * (60000.0f / INTERVALO_MUESTREO_MS);
    rpm2 = ((float)pulsos2 / PULSOS_POR_REVOLUCION) * (60000.0f / INTERVALO_MUESTREO_MS);

    // --- MOTOR 1 ---
    e1 = referenciaV1 - rpm1;
    u1 = u1_prev + (Kp + Ki*0.02f + Kd/0.02f)*e1 - (Kp + 2.0f*Kd/0.02f)*e1_prev1 + (Kd/0.02f)*e1_prev2;
    u1_prev = u1;
    e1_prev2 = e1_prev1;
    e1_prev1 = e1;

    // --- MOTOR 2 ---
    e2 = referenciaV2 - rpm2;
    u2 = u2_prev + (Kp + Ki*0.02f + Kd/0.02f)*e2 - (Kp + 2.0f*Kd/0.02f)*e2_prev1 + (Kd/0.02f)*e2_prev2;
    u2_prev = u2;
    e2_prev2 = e2_prev1;
    e2_prev1 = e2;

    // Saturación PWM (0 a 255)
    int pwmOut1 = constrain((int)abs(u1), 0, 255);
    int pwmOut2 = constrain((int)abs(u2), 0, 255);

    digitalWrite(PIN_DIR_1, (u1 >= 0) ? HIGH : LOW);
    digitalWrite(PIN_DIR_2, (u2 >= 0) ? HIGH : LOW);

    analogWrite(PIN_PWM_1, pwmOut1);
    analogWrite(PIN_PWM_2, pwmOut2);
  }

  // --- 3. TRANSMISIÓN DE TELEMETRÍA HACIA PYTHON (Cada 20ms) ---
  if (tiempoActual - tiempoAnteriorEnvio >= 20) {
    tiempoAnteriorEnvio = tiempoActual;
    
    float tiempoRelativo = tiempoActual / 1000.0f;
    
    Serial.print(tiempoRelativo, 2);
    Serial.print(",");
    Serial.print(rpm1, 1);
    Serial.print(",");
    Serial.print(rpm2, 1);
    Serial.print(",");
    Serial.print(referenciaV1, 1);
    Serial.print(",");
    Serial.println(referenciaV2, 1);
  }
}