clear all
clc

entrada=xlsread('Caracterizacion velocidad.CSV','B2:B1913');
tiempo=xlsread('Caracterizacion velocidad.CSV','A2:A1913');
pos=xlsread('Caracterizacion velocidad.CSV','D2:D1913');

plot(tiempo,entrada,tiempo,pos);

% % Definir la planta y1
% num = [4.289];
% den = [1, 2.728, 4.516];
% y1 = tf(num, den);
% 
% % Abrir la herramienta de sintonización interactiva
% pidTuner(y1, 'PID');