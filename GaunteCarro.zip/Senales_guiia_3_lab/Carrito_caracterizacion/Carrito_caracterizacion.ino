#include <Arduino.h>

// ==========================================
// PINES UBICADOS EN EL LADO IZQUIERDO DE LA ESP32
// ==========================================
const uint8_t PIN_ENC_1 = 32; // Encoder 1
const uint8_t PIN_ENC_2 = 33; // Encoder 2

const uint8_t PIN_PWM_1 = 25; // Motor 1 PWM
const uint8_t PIN_DIR_1 = 26; // Motor 1 Dirección

const uint8_t PIN_PWM_2 = 27; // Motor 2 PWM
const uint8_t PIN_DIR_2 = 13; // Motor 2 Dirección
// ==========================================

const uint16_t PULSOS_POR_REVOLUCION = 374; 
const unsigned long INTERVALO_CALCULO_MS = 20; 

volatile long contadorPulsos1 = 0;
volatile long contadorPulsos2 = 0;

float referenciaV = 0.0;
float kp1 = 1.0;
float kp2 = 1.0;

float rpm1 = 0.0;
float rpm2 = 0.0;

unsigned long tiempoAnterior = 0;
unsigned long tiempoInicio = 0;

const byte TAMANO_BUFFER = 32;
char bufferSerial[TAMANO_BUFFER];
boolean nuevaTrama = false;

void IRAM_ATTR isrEncoder1() {
  contadorPulsos1++;
}

void IRAM_ATTR isrEncoder2() {
  contadorPulsos2++;
}

void leerSerialConFormato();
void procesarComando();

void setup() {
  Serial.begin(115200);

  // Configuración de pines de Encoders
  pinMode(PIN_ENC_1, INPUT_PULLUP);
  pinMode(PIN_ENC_2, INPUT_PULLUP);

  // Configuración de pines de Drivers
  pinMode(PIN_PWM_1, OUTPUT);
  pinMode(PIN_DIR_1, OUTPUT);
  pinMode(PIN_PWM_2, OUTPUT);
  pinMode(PIN_DIR_2, OUTPUT);

  digitalWrite(PIN_DIR_1, HIGH);
  digitalWrite(PIN_DIR_2, HIGH);

  // Interrupciones por flancos
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_1), isrEncoder1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_2), isrEncoder2, CHANGE);

  tiempoInicio = millis();
}

void loop() {
  leerSerialConFormato();
  procesarComando();

  unsigned long tiempoActual = millis();
  if (tiempoActual - tiempoAnterior >= INTERVALO_CALCULO_MS) {
    tiempoAnterior = tiempoActual;

    noInterrupts();
    long pulsos1 = contadorPulsos1;
    long pulsos2 = contadorPulsos2;
    contadorPulsos1 = 0;
    contadorPulsos2 = 0;
    interrupts();

    rpm1 = ((float)pulsos1 / PULSOS_POR_REVOLUCION) * (60000.0f / INTERVALO_CALCULO_MS);
    rpm2 = ((float)pulsos2 / PULSOS_POR_REVOLUCION) * (60000.0f / INTERVALO_CALCULO_MS);

    int pwmOut1 = constrain((int)(referenciaV * kp1), 0, 255);
    int pwmOut2 = constrain((int)(referenciaV * kp2), 0, 255);

    analogWrite(PIN_PWM_1, pwmOut1);
    analogWrite(PIN_PWM_2, pwmOut2);

    float tiempoRelativo = (tiempoActual - tiempoInicio) / 1000.0f;
    Serial.print(tiempoRelativo, 3);
    Serial.print(",");
    Serial.print(rpm1, 2);
    Serial.print(",");
    Serial.println(rpm2, 2);
  }
}

void leerSerialConFormato() {
  static boolean enProgreso = false;
  static byte idx = 0;
  char marcaInicio = '<';
  char marcaFin = '>';
  char c;

  while (Serial.available() > 0 && !nuevaTrama) {
    c = Serial.read();

    if (enProgreso) {
      if (c != marcaFin) {
        bufferSerial[idx] = c;
        idx++;
        if (idx >= TAMANO_BUFFER) idx = TAMANO_BUFFER - 1;
      } else {
        bufferSerial[idx] = '\0';
        enProgreso = false;
        idx = 0;
        nuevaTrama = true;
      }
    } else if (c == marcaInicio) {
      enProgreso = true;
    }
  }
}

void procesarComando() {
  if (!nuevaTrama) return;

  if (bufferSerial[0] == 'V') {
    char* token = strtok(bufferSerial, ",");
    token = strtok(NULL, ",");
    if (token != NULL) referenciaV = atof(token);
  }
  else if (bufferSerial[0] == 'K' && bufferSerial[1] == 'P') {
    char* token = strtok(bufferSerial, ",");
    token = strtok(NULL, ",");
    if (token != NULL) kp1 = atof(token);
    token = strtok(NULL, ",");
    if (token != NULL) kp2 = atof(token);
  }

  nuevaTrama = false;
}