import customtkinter as ctk
import socket
import threading
import csv
from tkinter import filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# --- CONFIGURACIÓN DE RED (Wi-Fi UDP con el ESP32) ---
ESP32_IP = "192.168.4.1"  # IP del ESP32 (Red SAMPC)[cite: 1]
ESP32_PORT = 4210
LOCAL_PORT = 4210

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class RobotControlApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Control y Doble Gráfica (Sin Filtro vs Filtrado) - ESP32")
        self.geometry("1200x750")
        self.resizable(False, False)

        # Socket UDP
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("", LOCAL_PORT))
        self.sock.settimeout(0.1)

        self.running = True
        self.telemetry_data = []  # Almacena las tramas recibidas

        # --- DISTRIBUCIÓN PRINCIPAL (Paneles) ---
        self.left_frame = ctk.CTkFrame(self, width=340)
        self.left_frame.pack(side="left", fill="both", padx=10, pady=10)

        self.right_frame = ctk.CTkFrame(self)
        self.right_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)

        # ================= SECCIÓN IZQUIERDA: CONTROLES =================
        self.lbl_title = ctk.CTkLabel(self.left_frame, text="Panel de Control Wi-Fi", font=ctk.CTkFont(size=16, weight="bold"))
        self.lbl_title.pack(pady=10)

        # Control PWM
        self.lbl_speed = ctk.CTkLabel(self.left_frame, text="Velocidad PWM (0-255): 200", font=ctk.CTkFont(size=12))
        self.lbl_speed.pack(pady=5)
        self.slider_pwm = ctk.CTkSlider(self.left_frame, from_=50, to=255, number_of_steps=205, command=self.update_speed_label)
        self.slider_pwm.set(200)
        self.slider_pwm.pack(pady=5)

        # Botones de Movimiento
        self.btn_forward = ctk.CTkButton(self.left_frame, text="▲ AVANZAR (W)", fg_color="#2b8252", command=lambda: self.send_command("W"))
        self.btn_forward.pack(pady=4)

        self.mid_buttons = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        self.mid_buttons.pack(pady=4)
        self.btn_left = ctk.CTkButton(self.mid_buttons, text="◀ IZQ (A)", width=90, fg_color="#1f538d", command=lambda: self.send_command("A"))
        self.btn_left.pack(side="left", padx=3)
        self.btn_stop = ctk.CTkButton(self.mid_buttons, text="■ STOP", width=90, fg_color="#b83232", command=lambda: self.send_command("STOP"))
        self.btn_stop.pack(side="left", padx=3)
        self.btn_right = ctk.CTkButton(self.mid_buttons, text="RGT (D) ▶", width=90, fg_color="#1f538d", command=lambda: self.send_command("D"))
        self.btn_right.pack(side="left", padx=3)

        self.btn_backward = ctk.CTkButton(self.left_frame, text="▼ RETROCEDER (S)", fg_color="#2b8252", command=lambda: self.send_command("S"))
        self.btn_backward.pack(pady=4)

        self.btn_reset = ctk.CTkButton(self.left_frame, text="🔄 Resetear Posición", fg_color="#555555", command=lambda: self.send_raw_command("RESET"))
        self.btn_reset.pack(pady=10)

        # Filtros Core 0
        self.lbl_f_title = ctk.CTkLabel(self.left_frame, text="Filtros Digitales (Core 0)", font=ctk.CTkFont(size=14, weight="bold"))
        self.lbl_f_title.pack(pady=5)
        
        self.f_row1 = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        self.f_row1.pack(pady=2)
        ctk.CTkButton(self.f_row1, text="FIR ON", width=95, fg_color="#3b6978", command=lambda: self.send_raw_command("FIR_ON")).pack(side="left", padx=3)
        ctk.CTkButton(self.f_row1, text="FIR OFF", width=95, fg_color="#6d8299", command=lambda: self.send_raw_command("FIR_OFF")).pack(side="left", padx=3)

        self.f_row2 = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        self.f_row2.pack(pady=2)
        ctk.CTkButton(self.f_row2, text="IIR ON", width=95, fg_color="#3b6978", command=lambda: self.send_raw_command("IRR_ON")).pack(side="left", padx=3)
        ctk.CTkButton(self.f_row2, text="IIR OFF", width=95, fg_color="#6d8299", command=lambda: self.send_raw_command("IRR_OFF")).pack(side="left", padx=3)

        # Gestión de Datos (Exportar / Cargar)
        self.lbl_data_title = ctk.CTkLabel(self.left_frame, text="Gestión de Datos", font=ctk.CTkFont(size=14, weight="bold"))
        self.lbl_data_title.pack(pady=(15, 5))

        self.btn_export = ctk.CTkButton(self.left_frame, text="💾 Exportar Telemetría (CSV)", fg_color="#2980b9", command=self.export_csv)
        self.btn_export.pack(pady=4)

        self.btn_load = ctk.CTkButton(self.left_frame, text="📂 Cargar & Graficar CSV", fg_color="#8e44ad", command=self.load_and_plot_csv)
        self.btn_load.pack(pady=4)

        # ================= SECCIÓN DERECHA: DOBLE GRÁFICA MATPLOTLIB =================
        self.lbl_tel_title = ctk.CTkLabel(self.right_frame, text="Telemetría en Vivo", font=ctk.CTkFont(size=16, weight="bold"))
        self.lbl_tel_title.pack(pady=5)

        self.lbl_t = ctk.CTkLabel(self.right_frame, text="⏱ Tiempo: 0.0 s | 🚗 M1: 0.00 cm | 🚗 M2: 0.00 cm", font=ctk.CTkFont(size=12))
        self.lbl_t.pack(pady=2)

        # Crear figura con 2 subplots (subgráficas apiladas verticalmente)
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(7, 6))
        self.fig.tight_layout(pad=3.0)
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.right_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)

        # Hilo de escucha UDP
        self.udp_thread = threading.Thread(target=self.receive_telemetry, daemon=True)
        self.udp_thread.start()

    def update_speed_label(self, value):
        self.lbl_speed.configure(text=f"Velocidad PWM (0-255): {int(value)}")

    def send_command(self, action):
        pwm = int(self.slider_pwm.get())
        cmd = "STOP" if action == "STOP" else f"{action}{pwm}"
        self.send_raw_command(cmd)

    def send_raw_command(self, cmd):
        try:
            self.sock.sendto(cmd.encode('utf-8'), (ESP32_IP, ESP32_PORT))
        except Exception as e:
            print(f"Error al enviar comando: {e}")

    def receive_telemetry(self):
        while self.running:
            try:
                data, _ = self.sock.recvfrom(1024)
                message = data.decode('utf-8').strip()
                parts = message.split(',')
                if len(parts) == 7:
                    self.telemetry_data.append([float(p) for p in parts])
                    self.after(0, lambda: self.update_live_view(parts))
            except socket.timeout:
                continue
            except Exception as e:
                print(f"Error UDP: {e}")

    def update_live_view(self, parts):
        t, m1, m2, mpu_raw, m1_f, m2_f, mpu_f = parts
        self.lbl_t.configure(text=f"⏱ Tiempo: {float(t):.1f}s | 🚗 M1: {float(m1):.2f}cm | 🚗 M2: {float(m2):.2f}cm")

        # Dibujar gráficos en tiempo real usando las últimas 100 muestras
        if len(self.telemetry_data) > 1:
            times = [row[0] for row in self.telemetry_data[-100:]]
            raw_vals = [row[3] for row in self.telemetry_data[-100:]]
            filt_vals = [row[6] for row in self.telemetry_data[-100:]]

            # Gráfica 1: Sin filtro (Datos Crudos)
            self.ax1.clear()
            self.ax1.plot(times, raw_vals, label="MPU Cruda (Sin Filtro)", color="crimson", alpha=0.8)
            self.ax1.set_title("Señal Sin Filtro")
            self.ax1.set_ylabel("Ángulo (°)")
            self.ax1.legend(loc="upper left")
            self.ax1.grid(True)

            # Gráfica 2: Datos Filtrados
            self.ax2.clear()
            self.ax2.plot(times, filt_vals, label="MPU Filtrada (FIR/IIR)", color="forestgreen", linewidth=2)
            self.ax2.set_title("Señal Filtrada (Core 0)")
            self.ax2.set_xlabel("Tiempo (s)")
            self.ax2.set_ylabel("Ángulo (°)")
            self.ax2.legend(loc="upper left")
            self.ax2.grid(True)

            self.fig.tight_layout()
            self.canvas.draw()

    def export_csv(self):
        if not self.telemetry_data:
            print("No hay datos para exportar.")
            return
        
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
        if file_path:
            with open(file_path, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Tiempo", "Motor1", "Motor2", "MPU_Cruda", "Motor1_Filtrado", "Motor2_Filtrado", "MPU_Filtrada"])
                writer.writerows(self.telemetry_data)
            print(f"Datos exportados a: {file_path}")

    def load_and_plot_csv(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if file_path:
            times, mpu_raw, mpu_filt = [], [], []
            with open(file_path, mode='r') as f:
                reader = csv.reader(f)
                next(reader)
                for row in reader:
                    if len(row) == 7:
                        times.append(float(row[0]))
                        mpu_raw.append(float(row[3]))
                        mpu_filt.append(float(row[6]))

            # Ventana emergente con dos gráficas separadas para el archivo cargado
            fig_loaded, (ax_l1, ax_l2) = plt.subplots(2, 1, figsize=(7, 6))
            
            ax_l1.plot(times, mpu_raw, label="CSV - MPU Cruda", color="crimson")
            ax_l1.set_title("Análisis Post-Procesamiento: Señal Sin Filtro")
            ax_l1.set_ylabel("Ángulo (°)")
            ax_l1.legend()
            ax_l1.grid(True)

            ax_l2.plot(times, mpu_filt, label="CSV - MPU Filtrada", color="blue", linewidth=2)
            ax_l2.set_title("Análisis Post-Procesamiento: Señal Filtrada")
            ax_l2.set_xlabel("Tiempo (s)")
            ax_l2.set_ylabel("Ángulo (°)")
            ax_l2.legend()
            ax_l2.grid(True)

            fig_loaded.tight_layout()
            plt.show()

    def onClose(self):
        self.running = False
        self.sock.close()
        self.destroy()

if __name__ == "__main__":
    app = RobotControlApp()
    app.protocol("WM_DELETE_WINDOW", app.onClose)
    app.mainloop()
