#include <WiFi.h>

void setup() {
  // Iniciar la comunicación serial
  Serial.begin(115200);
  while (!Serial); // Esperar a que se abra el puerto serie

  // Iniciar el módulo WiFi (no es necesario conectarse a una red para leer la MAC)
  WiFi.mode(WIFI_STA);
  WiFi.begin();

  // Esperar un breve momento para asegurar la inicialización
  delay(1000);

  Serial.println("\n--- LECTOR DE DIRECCIÓN MAC ESP32 ---");
  
  // Obtener e imprimir la dirección MAC
  String macAddress = WiFi.macAddress();
  
  Serial.print("Dirección MAC: ");
  Serial.println(macAddress);
}

void loop() {
  // El código no necesita hacer nada en el loop
}