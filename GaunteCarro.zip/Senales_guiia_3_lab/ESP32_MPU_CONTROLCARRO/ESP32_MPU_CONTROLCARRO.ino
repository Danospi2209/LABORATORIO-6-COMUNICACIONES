// ===================== PINES TB6612 (Pines consecutivos) =====================
// Regleta Motor A (GPIOs 12, 13, 14 consecutivos en placa)
const int PWMA1 = 4; // Control de velocidad Motor A (PWM)
const int AIN1  = 16; // Dirección Motor A1
const int AIN2  = 17; // Dirección Motor A2

// Regleta Motor B (GPIOs 25, 26, 27 consecutivos en placa)
const int PWMB1 = 25; // Control de velocidad Motor B (PWM)
const int BIN1  = 26; // Dirección Motor B1
const int BIN2  = 27; // Dirección Motor B2

// Velocidad por defecto (0 a 255)
const int VELOCIDAD = 180;

void setup() {
  Serial.begin(115200);

  // Configurar pines de control como salidas
  pinMode(PWMA1, OUTPUT);
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  
  pinMode(PWMB1, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);

  // Asegurar motores detenidos al arrancar
  moverMotores(0, 0, 0, 0);

  Serial.println("Iniciando prueba de motores con TB6612FNG (Pines consecutivos)...");
}

void loop() {
  // 1. ADELANTE (Ambos motores giran en avance)
  Serial.println("Moviendo: ADELANTE");
  moverMotores(1, VELOCIDAD, 1, VELOCIDAD);
  delay(2000);

  // Pausa de seguridad
  pararMotores();
  delay(1000);

  // 2. ATRÁS (Ambos motores en retroceso)
  Serial.println("Moviendo: ATRAS");
  moverMotores(-1, VELOCIDAD, -1, VELOCIDAD);
  delay(2000);

  pararMotores();
  delay(1000);

  // 3. IZQUIERDA (Giro sobre su eje: Motor izq atrás, Motor der adelante)
  Serial.println("Moviendo: IZQUIERDA");
  moverMotores(-1, VELOCIDAD, 1, VELOCIDAD);
  delay(1500);

  pararMotores();
  delay(1000);

  // 4. DERECHA (Giro sobre su eje: Motor izq adelante, Motor der atrás)
  Serial.println("Moviendo: DERECHA");
  moverMotores(1, VELOCIDAD, -1, VELOCIDAD);
  delay(1500);

  // STOP final antes de repetir el ciclo
  Serial.println("Moviendo: STOP");
  pararMotores();
  delay(3000);
}

// ===================== FUNCIONES AUXILIARES =====================

// dirM1 y dirM2: 1 (Adelante), -1 (Atrás), 0 (Detenido)
// pwm1 y pwm2: 0 a 255
void moverMotores(int dirM1, int pwm1, int dirM2, int pwm2) {
  // Limitar valores de PWM de forma segura
  pwm1 = constrain(pwm1, 0, 255);
  pwm2 = constrain(pwm2, 0, 255);

  // Control Motor A (Izquierdo)
  if (dirM1 > 0) {
    digitalWrite(AIN1, HIGH);
    digitalWrite(AIN2, LOW);
  } else if (dirM1 < 0) {
    digitalWrite(AIN1, LOW);
    digitalWrite(AIN2, HIGH);
  } else {
    digitalWrite(AIN1, LOW);
    digitalWrite(AIN2, LOW);
    pwm1 = 0;
  }
  analogWrite(PWMA1, pwm1);

  // Control Motor B (Derecho)
  if (dirM2 > 0) {
    digitalWrite(BIN1, HIGH);
    digitalWrite(BIN2, LOW);
  } else if (dirM2 < 0) {
    digitalWrite(BIN1, LOW);
    digitalWrite(BIN2, HIGH);
  } else {
    digitalWrite(BIN1, LOW);
    digitalWrite(BIN2, LOW);
    pwm2 = 0;
  }
  analogWrite(PWMB1, pwm2);
}

void pararMotores() {
  moverMotores(0, 0, 0, 0);
}