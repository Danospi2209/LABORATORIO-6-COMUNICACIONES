// Firmware ESP32 del carro: motores TB6612, encoders, MPU6050 y telemetría UDP.
// Requiere ESP32 Arduino core 3.x (analogWrite).
//
// Protocolo (texto, UDP, puerto 4210):
//   Carro -> PC : C,SEQ:n,T:ms,MPU:..,MPUF:..,VM1:..,VM2:..,POS:..,VFM1:..,VFM2:..,POSF:..,XMPU:..,YMPU:..,XENC:..,YENC:..
//   PC -> Carro : HB | MOV:<ADELANTE|ATRAS|IZQ|DER|STOP>,PWM:<0-255> | KALMAN:<0.01-1.0> | RESET
//
// Descubrimiento: mientras el carro no conoce al PC, transmite por broadcast.
// Al recibir el primer paquete del PC (el heartbeat "HB"), pasa a unicast a esa IP.

#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>

// ===================== RED =====================
const char* WIFI_SSID = "moto sam";   // <- completa con tu red 2.4 GHz
const char* WIFI_PASS = "Samlopez246";     // <- completa con tu contraseña
const uint16_t PUERTO_UDP = 4210;

WiFiUDP udp;
bool udpIniciado = false;
IPAddress ipPC;
bool pcConocido = false;
unsigned long ultimoRxPC = 0;
unsigned long ultimoIntentoWifi = 0;
const unsigned long TIMEOUT_ENLACE_MS = 1500;  // sin mensajes del PC -> frena motores
const unsigned long TIMEOUT_PC_MS = 5000;      // sin mensajes del PC -> vuelve a broadcast
uint32_t secuencia = 0;

// ===================== PINES TB6612 =====================
const int PWMA1 = 5,  AIN1 = 19, AIN2 = 18;
const int PWMB1 = 4,  BIN1 = 17, BIN2 = 16;
const int STBY = 23;

// ===================== ENCODERS Y RUEDAS =====================
const int ENCODER_M1_PIN = 34;
const int ENCODER_M2_PIN = 35;
const unsigned long DEBOUNCE_US = 100;  // filtra rebotes; ponlo en 0 para desactivar

volatile long pulsosM1 = 0, pulsosM2 = 0;
volatile unsigned long tUltM1 = 0, tUltM2 = 0;

// Encoders de un solo canal: no detectan sentido. Se usa el último sentido ordenado.
int sentidoEncM1 = 1, sentidoEncM2 = 1;
bool movimientoActivo = false;

const float DIAMETRO_RUEDA = 0.049;  // m
const float PERIMETRO_RUEDA = PI * DIAMETRO_RUEDA;
const int PPR = 370;
const float DISTANCIA_ENTRE_RUEDAS = 0.15;  // m

float velocidadM1 = 0, velocidadM2 = 0;
float posicionM1 = 0, posicionM2 = 0;  // m, con signo
float velocidadFiltradaM1 = 0, velocidadFiltradaM2 = 0;
float posicionFiltradaCarrito = 0;

// ===================== MPU6050 =====================
const uint8_t MPU_ADDR = 0x68;
const float ZONA_MUERTA_GIRO = 0.3;  // °/s, evita que el ruido integre deriva
float sesgoGiroZ = 0;                // calibrado al arrancar (carro quieto)
float mpuCrudoZ = 0, mpuFiltradoZ = 0;

// FIR media móvil de 5 taps
const int FIR_TAPS = 5;
float bufferFIR[FIR_TAPS] = {0};
int indiceFIR = 0;

// Kalman escalar: Q = "agresividad" (slider del PC), R = ruido de medida
float kalmanX = 0, kalmanP = 1.0;
float kalmanQ = 0.5;
const float KALMAN_R = 1.0;

// ===================== TRAYECTORIAS =====================
float orientacionMPU = 0, orientacionEnc = 0;  // rad
float posX_mpu = 0, posY_mpu = 0, posX_enc = 0, posY_enc = 0;  // cm

// ===================== TEMPORIZACIÓN =====================
const unsigned long PERIODO_US = 50000;  // 20 Hz
unsigned long ultimoUs = 0;

// ===================== INTERRUPCIONES =====================
void IRAM_ATTR contarM1() {
  unsigned long t = micros();
  if (t - tUltM1 >= DEBOUNCE_US) { pulsosM1++; tUltM1 = t; }
}
void IRAM_ATTR contarM2() {
  unsigned long t = micros();
  if (t - tUltM2 >= DEBOUNCE_US) { pulsosM2++; tUltM2 = t; }
}

// ===================== MPU6050 =====================
void inicializarMPU() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0);  // sale de sleep
  Wire.endTransmission(true);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x1B);
  Wire.write(0x08);  // ±500 °/s -> 65.5 LSB/(°/s)
  Wire.endTransmission(true);
}

bool leerGiroZ(float &gz) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x47);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(MPU_ADDR, (uint8_t)2, (uint8_t)true) != 2) return false;
  // Lecturas separadas: en C++ el orden de evaluación de "a() | b()" no está garantizado.
  uint8_t hi = Wire.read();
  uint8_t lo = Wire.read();
  gz = (int16_t)((hi << 8) | lo) / 65.5f;
  return true;
}

void calibrarGiro() {
  float suma = 0;
  int n = 0;
  for (int i = 0; i < 200; i++) {
    float g;
    if (leerGiroZ(g)) { suma += g; n++; }
    delay(5);
  }
  if (n > 0) sesgoGiroZ = suma / n;
  Serial.printf("Sesgo giroscopio Z: %.3f °/s (%d muestras)\n", sesgoGiroZ, n);
}

// ===================== MOTORES =====================
void moverMotores(int dirM1, int pwm1, int dirM2, int pwm2) {
  pwm1 = constrain(pwm1, 0, 255);
  pwm2 = constrain(pwm2, 0, 255);

  if (dirM1 > 0)      { digitalWrite(AIN1, HIGH); digitalWrite(AIN2, LOW);  sentidoEncM1 = 1; }
  else if (dirM1 < 0) { digitalWrite(AIN1, LOW);  digitalWrite(AIN2, HIGH); sentidoEncM1 = -1; }
  else                { digitalWrite(AIN1, LOW);  digitalWrite(AIN2, LOW);  pwm1 = 0; }
  analogWrite(PWMA1, pwm1);

  if (dirM2 > 0)      { digitalWrite(BIN1, HIGH); digitalWrite(BIN2, LOW);  sentidoEncM2 = 1; }
  else if (dirM2 < 0) { digitalWrite(BIN1, LOW);  digitalWrite(BIN2, HIGH); sentidoEncM2 = -1; }
  else                { digitalWrite(BIN1, LOW);  digitalWrite(BIN2, LOW);  pwm2 = 0; }
  analogWrite(PWMB1, pwm2);

  movimientoActivo = (dirM1 != 0 || dirM2 != 0);
}

void reiniciarOdometria() {
  posicionM1 = posicionM2 = posicionFiltradaCarrito = 0;
  orientacionMPU = orientacionEnc = 0;
  posX_mpu = posY_mpu = posX_enc = posY_enc = 0;
}

// ===================== COMANDOS =====================
// Devuelve true si el mensaje era un comando válido del PC.
bool procesarComandoWifi(char* buf) {
  // Quita espacios/saltos de línea finales
  int len = strlen(buf);
  while (len > 0 && (buf[len - 1] == '\n' || buf[len - 1] == '\r' || buf[len - 1] == ' ')) buf[--len] = 0;

  if (strcmp(buf, "HB") == 0) return true;
  if (strcmp(buf, "RESET") == 0) { reiniciarOdometria(); return true; }

  bool reconocido = false, hayMov = false;
  char mov[12] = "";
  int pwm = 180;

  char* ctx;
  for (char* tok = strtok_r(buf, ",", &ctx); tok; tok = strtok_r(NULL, ",", &ctx)) {
    char* sep = strchr(tok, ':');
    if (!sep) continue;
    *sep = 0;
    const char* clave = tok;
    const char* valor = sep + 1;

    if (strcmp(clave, "MOV") == 0) {
      strncpy(mov, valor, sizeof(mov) - 1);
      mov[sizeof(mov) - 1] = 0;
      hayMov = reconocido = true;
    } else if (strcmp(clave, "PWM") == 0) {
      pwm = constrain(atoi(valor), 0, 255);
    } else if (strcmp(clave, "KALMAN") == 0) {
      kalmanQ = constrain(atof(valor), 0.01f, 1.0f);
      reconocido = true;
    }
  }

  if (hayMov) {
    if      (strcmp(mov, "ADELANTE") == 0) moverMotores(1, pwm, 1, pwm);
    else if (strcmp(mov, "ATRAS") == 0)    moverMotores(-1, pwm, -1, pwm);
    else if (strcmp(mov, "IZQ") == 0)      moverMotores(-1, pwm, 1, pwm);
    else if (strcmp(mov, "DER") == 0)      moverMotores(1, pwm, -1, pwm);
    else                                   moverMotores(0, 0, 0, 0);  // STOP o desconocido
  }
  return reconocido;
}

void recibirComandos() {
  while (udp.parsePacket() > 0) {
    char buf[128];
    int len = udp.read(buf, sizeof(buf) - 1);  // -1: deja espacio al terminador
    if (len <= 0) continue;
    buf[len] = 0;
    IPAddress origen = udp.remoteIP();
    if (procesarComandoWifi(buf)) {
      ipPC = origen;          // aprende la IP del PC
      pcConocido = true;
      ultimoRxPC = millis();
    }
  }
}

// ===================== TELEMETRÍA =====================
void enviarTelemetria(float mpuC, float vM1, float vM2, float posC,
                      float mpuF, float vFM1, float vFM2, float posFC,
                      float xM, float yM, float xE, float yE) {
  char payload[320];
  int n = snprintf(payload, sizeof(payload),
      "C,SEQ:%lu,T:%lu,MPU:%.2f,VM1:%.2f,VM2:%.2f,POS:%.2f,MPUF:%.2f,"
      "VFM1:%.2f,VFM2:%.2f,POSF:%.2f,XMPU:%.2f,YMPU:%.2f,XENC:%.2f,YENC:%.2f",
      (unsigned long)secuencia++, millis(), mpuC, vM1, vM2, posC, mpuF,
      vFM1, vFM2, posFC, xM, yM, xE, yE);
  if (n <= 0 || n >= (int)sizeof(payload)) return;  // sin truncar tramas

  IPAddress destino = pcConocido ? ipPC : WiFi.broadcastIP();
  udp.beginPacket(destino, PUERTO_UDP);
  udp.write((const uint8_t*)payload, n);
  udp.endPacket();
}

// ===================== MUESTREO (20 Hz) =====================
void muestrear() {
  unsigned long ahoraUs = micros();
  float dt = (ahoraUs - ultimoUs) / 1e6f;
  ultimoUs = ahoraUs;

  noInterrupts();
  long pM1 = pulsosM1, pM2 = pulsosM2;
  pulsosM1 = 0; pulsosM2 = 0;
  interrupts();

  // Distancia con signo (sentido ordenado a cada motor)
  float dM1 = sentidoEncM1 * ((float)pM1 / PPR) * PERIMETRO_RUEDA;
  float dM2 = sentidoEncM2 * ((float)pM2 / PPR) * PERIMETRO_RUEDA;
  velocidadM1 = dM1 / dt;
  velocidadM2 = dM2 / dt;

  posicionM1 += dM1;
  posicionM2 += dM2;
  float posicionCarrito = (posicionM1 + posicionM2) / 2.0;

  velocidadFiltradaM1 = 0.8 * velocidadFiltradaM1 + 0.2 * velocidadM1;
  velocidadFiltradaM2 = 0.8 * velocidadFiltradaM2 + 0.2 * velocidadM2;
  posicionFiltradaCarrito = 0.9 * posicionFiltradaCarrito + 0.1 * posicionCarrito;

  // --- MPU6050 (se conserva la última lectura si el bus I2C falla) ---
  float gz;
  if (leerGiroZ(gz)) mpuCrudoZ = gz - sesgoGiroZ;  // "crudo" = lectura menos sesgo

  bufferFIR[indiceFIR] = mpuCrudoZ;
  indiceFIR = (indiceFIR + 1) % FIR_TAPS;
  float mpuFIR = 0;
  for (int i = 0; i < FIR_TAPS; i++) mpuFIR += bufferFIR[i];
  mpuFIR /= FIR_TAPS;

  // Kalman escalar (predicción + corrección)
  kalmanP += kalmanQ;
  float K = kalmanP / (kalmanP + KALMAN_R);
  kalmanX += K * (mpuFIR - kalmanX);
  kalmanP *= (1.0f - K);
  mpuFiltradoZ = kalmanX;

  // --- Mapas X-Y ---
  float distanciaPasoCm = (dM1 + dM2) / 2.0f * 100.0f;

  float wMPU = (fabs(mpuFiltradoZ) < ZONA_MUERTA_GIRO) ? 0.0f : mpuFiltradoZ;
  orientacionMPU += wMPU * (PI / 180.0f) * dt;
  posX_mpu += distanciaPasoCm * cos(orientacionMPU);
  posY_mpu += distanciaPasoCm * sin(orientacionMPU);

  float wEnc = (velocidadM2 - velocidadM1) / DISTANCIA_ENTRE_RUEDAS;  // rad/s
  orientacionEnc += wEnc * dt;
  posX_enc += distanciaPasoCm * cos(orientacionEnc);
  posY_enc += distanciaPasoCm * sin(orientacionEnc);

  enviarTelemetria(mpuCrudoZ, velocidadM1, velocidadM2, posicionCarrito,
                   mpuFiltradoZ, velocidadFiltradaM1, velocidadFiltradaM2, posicionFiltradaCarrito,
                   posX_mpu, posY_mpu, posX_enc, posY_enc);
}

void reiniciarMuestreo() {
  noInterrupts();
  pulsosM1 = 0; pulsosM2 = 0;
  interrupts();
  ultimoUs = micros();
}

// ===================== WIFI =====================
void conectarWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);  // sin ahorro de energía: menor latencia y menos pérdidas UDP
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  Serial.print("Conectando carro a Wi-Fi");
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) {
    delay(500);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("\nCarro conectado. IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nNo se pudo conectar; se seguirá intentando en el loop.");
  }
}

// ===================== SETUP / LOOP =====================
void setup() {
  Serial.begin(115200);

  pinMode(PWMA1, OUTPUT); pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(PWMB1, OUTPUT); pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(STBY, OUTPUT);
  digitalWrite(STBY, HIGH);
  moverMotores(0, 0, 0, 0);

  pinMode(ENCODER_M1_PIN, INPUT);
  pinMode(ENCODER_M2_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(ENCODER_M1_PIN), contarM1, RISING);
  attachInterrupt(digitalPinToInterrupt(ENCODER_M2_PIN), contarM2, RISING);

  Wire.begin(21, 22);
  Wire.setClock(400000);
  Wire.setTimeOut(20);
  inicializarMPU();
  Serial.println("MPU6050 inicializado. Mantén el carro quieto: calibrando giroscopio...");
  calibrarGiro();

  conectarWifi();
  if (WiFi.status() == WL_CONNECTED) {
    udp.begin(PUERTO_UDP);
    udpIniciado = true;
  }
  ultimoUs = micros();
}

void loop() {
  unsigned long ahoraMs = millis();

  // Sin Wi-Fi: frena y reintenta cada 5 s
  if (WiFi.status() != WL_CONNECTED) {
    moverMotores(0, 0, 0, 0);
    pcConocido = false;
    if (ahoraMs - ultimoIntentoWifi > 5000) {
      ultimoIntentoWifi = ahoraMs;
      WiFi.reconnect();
    }
    reiniciarMuestreo();
    delay(10);
    return;
  }

  if (!udpIniciado) {
    udp.begin(PUERTO_UDP);
    udpIniciado = true;
  }

  recibirComandos();

  // Vigilancia del enlace con el PC
  if (pcConocido && ahoraMs - ultimoRxPC > TIMEOUT_PC_MS) pcConocido = false;
  if (movimientoActivo && ahoraMs - ultimoRxPC > TIMEOUT_ENLACE_MS) {
    moverMotores(0, 0, 0, 0);  // failsafe: se perdió el control
  }

  if (micros() - ultimoUs >= PERIODO_US) muestrear();

  delay(1);  // cede CPU a la pila Wi-Fi
}
