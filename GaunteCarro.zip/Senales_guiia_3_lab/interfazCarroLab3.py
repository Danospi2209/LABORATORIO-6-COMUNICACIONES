import sys
import numpy as np
import pandas as pd
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QComboBox, QPushButton, 
                             QTabWidget, QFileDialog, QMessageBox, QGroupBox, QGridLayout, QSlider)
from PyQt5.QtCore import QTimer, Qt
import pyqtgraph as pg
import serial
import serial.tools.list_ports

class ControlStationApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Estación de Control - Telemetría Completa (Mano, Carro MPU y Encoders)")
        self.resize(1650, 1050)

        self.ser = None
        self.is_connected = False

        self.max_len = 200
        
        # Buffers para la Mano (X e Y)
        self.hand_x_raw = np.zeros(self.max_len)
        self.hand_x_filt = np.zeros(self.max_len)
        self.hand_y_raw = np.zeros(self.max_len)
        self.hand_y_filt = np.zeros(self.max_len)

        # Buffers para el Carro (MPU X e Y)
        self.car_mpu_x_raw = np.zeros(self.max_len)
        self.car_mpu_x_filt = np.zeros(self.max_len)
        self.car_mpu_y_raw = np.zeros(self.max_len)
        self.car_mpu_y_filt = np.zeros(self.max_len)
        
        # Buffers para Motores y Encoders
        self.m1_raw = np.zeros(self.max_len)
        self.m1_filt = np.zeros(self.max_len)
        self.m2_raw = np.zeros(self.max_len)
        self.m2_filt = np.zeros(self.max_len)
        
        self.enc1_vals = np.zeros(self.max_len)
        self.enc2_vals = np.zeros(self.max_len)

        self.x_traj = [0.0]
        self.y_traj = [0.0]
        self.all_logged_data = []

        self.init_ui()

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_data)
        self.timer.start(20)

    def init_ui(self):
        tabs = QTabWidget()
        self.setCentralWidget(tabs)

        tab_live = QWidget()
        layout_live = QHBoxLayout(tab_live)

        left_ctrl = QVBoxLayout()
        
        left_ctrl.addWidget(QLabel("<b>Puerto Serial Gateway (ESP32-S3):</b>"))
        port_layout = QHBoxLayout()
        self.combo_ports = QComboBox()
        self.refresh_ports()
        port_layout.addWidget(self.combo_ports)
        
        btn_refresh_ports = QPushButton("Actualizar")
        btn_refresh_ports.clicked.connect(self.refresh_ports)
        port_layout.addWidget(btn_refresh_ports)
        left_ctrl.addLayout(port_layout)

        self.btn_connect = QPushButton("Conectar")
        self.btn_connect.setStyleSheet("background-color: #d4edda; color: #155724; font-weight: bold;")
        self.btn_connect.clicked.connect(self.toggle_connection)
        left_ctrl.addWidget(self.btn_connect)

        left_ctrl.addWidget(QLabel("<hr>"))

        # Selector de Método
        left_ctrl.addWidget(QLabel("<b>Método de Filtrado Activo (Mano):</b>"))
        self.combo_filter = QComboBox()
        self.combo_filter.addItems(["Filtro Kalman", "Filtro FIR"])
        self.combo_filter.currentIndexChanged.connect(self.change_filter_method)
        left_ctrl.addWidget(self.combo_filter)

        left_ctrl.addWidget(QLabel("<hr>"))

        # Controles de Agresividad
        left_ctrl.addWidget(QLabel("<b>Agresividad - Kalman (Ruido R):</b>"))
        self.slider_kalman = QSlider(Qt.Horizontal)
        self.slider_kalman.setRange(1, 100)
        self.slider_kalman.setValue(40)
        self.slider_kalman.valueChanged.connect(self.change_kalman_aggressiveness)
        left_ctrl.addWidget(self.slider_kalman)

        left_ctrl.addWidget(QLabel("<b>Agresividad - FIR (Ventana):</b>"))
        self.slider_fir = QSlider(Qt.Horizontal)
        self.slider_fir.setRange(2, 25)
        self.slider_fir.setValue(8)
        self.slider_fir.valueChanged.connect(self.change_fir_aggressiveness)
        left_ctrl.addWidget(self.slider_fir)

        left_ctrl.addWidget(QLabel("<hr>"))

        # Panel de Datos en Tiempo Real
        group_realtime = QGroupBox("Valores Instantáneos")
        grid_rt = QGridLayout()
        self.lbl_hx = QLabel("Hand X: 0.00°")
        self.lbl_hy = QLabel("Hand Y: 0.00°")
        self.lbl_cx = QLabel("Car MPU X: 0.00°")
        self.lbl_cy = QLabel("Car MPU Y: 0.00°")
        self.lbl_enc = QLabel("Enc 1: 0 | Enc 2: 0")
        
        grid_rt.addWidget(self.lbl_hx, 0, 0)
        grid_rt.addWidget(self.lbl_hy, 0, 1)
        grid_rt.addWidget(self.lbl_cx, 1, 0)
        grid_rt.addWidget(self.lbl_cy, 1, 1)
        grid_rt.addWidget(self.lbl_enc, 2, 0, 1, 2)
        group_realtime.setLayout(grid_rt)
        left_ctrl.addWidget(group_realtime)

        left_ctrl.addWidget(QLabel("<hr>"))
        btn_export = QPushButton("Exportar Datos a Excel")
        btn_export.clicked.connect(self.export_to_excel)
        left_ctrl.addWidget(btn_export)
        
        left_ctrl.addStretch()
        layout_live.addLayout(left_ctrl, 1)

        # Panel de Gráficas Separadas
        plots_layout = QVBoxLayout()
        pg.setConfigOptions(antialias=True)
        self.plot_widget = pg.GraphicsLayoutWidget()
        
        # 1. Mano Eje X
        self.p1 = self.plot_widget.addPlot(row=0, col=0, title="Mano - Eje X (Crudo vs Filtrado)")
        self.curve_hx_raw = self.p1.plot(pen=pg.mkPen('y', style=pg.QtCore.Qt.DotLine), name="Raw X")
        self.curve_hx_filt = self.p1.plot(pen=pg.mkPen('orange', width=2), name="Filt X")

        # 2. Mano Eje Y
        self.p2 = self.plot_widget.addPlot(row=1, col=0, title="Mano - Eje Y (Crudo vs Filtrado)")
        self.curve_hy_raw = self.p2.plot(pen=pg.mkPen('blue', style=pg.QtCore.Qt.DotLine), name="Raw Y")
        self.curve_hy_filt = self.p2.plot(pen=pg.mkPen('cyan', width=2), name="Filt Y")

        # 3. Carro MPU Eje X
        self.p3 = self.plot_widget.addPlot(row=2, col=0, title="Carro - MPU Eje X (Crudo vs Filtrado)")
        self.curve_cx_raw = self.p3.plot(pen=pg.mkPen('magenta', style=pg.QtCore.Qt.DotLine), name="Car X Raw")
        self.curve_cx_filt = self.p3.plot(pen=pg.mkPen('green', width=2), name="Car X Filt")

        # 4. Carro MPU Eje Y
        self.p4 = self.plot_widget.addPlot(row=3, col=0, title="Carro - MPU Eje Y (Crudo vs Filtrado)")
        self.curve_cy_raw = self.p4.plot(pen=pg.mkPen('pink', style=pg.QtCore.Qt.DotLine), name="Car Y Raw")
        self.curve_cy_filt = self.p4.plot(pen=pg.mkPen('lime', width=2), name="Car Y Filt")

        # 5. Motores (1 y 2)
        self.p5 = self.plot_widget.addPlot(row=4, col=0, title="Motores PWM (Motor 1 y Motor 2)")
        self.curve_m1 = self.p5.plot(pen=pg.mkPen('red', width=2), name="Motor 1")
        self.curve_m2 = self.p5.plot(pen=pg.mkPen('yellow', width=2), name="Motor 2")

        # 6. Encoders
        self.p6 = self.plot_widget.addPlot(row=5, col=0, title="Encoders del Carro (Enc 1 y Enc 2)")
        self.curve_enc1 = self.p6.plot(pen=pg.mkPen('white', width=2), name="Encoder 1")
        self.curve_enc2 = self.p6.plot(pen=pg.mkPen('lightblue', width=2), name="Encoder 2")

        plots_layout.addWidget(self.plot_widget, 6)

        # Mapa 2D de Posición del Carrito
        self.p_map = self.plot_widget.addPlot(row=0, col=1, rowspan=6, title="Trayectoria 2D del Carrito")
        self.curve_trajectory = self.p_map.plot(pen=pg.mkPen('lime', width=3))

        layout_live.addLayout(plots_layout, 4)
        tabs.addTab(tab_live, "Monitoreo Independiente y Sensores")

    def refresh_ports(self):
        self.combo_ports.clear()
        for port in serial.tools.list_ports.comports():
            self.combo_ports.addItem(port.device)
        if self.combo_ports.count() == 0:
            self.combo_ports.addItem("No COM found")

    def toggle_connection(self):
        if not self.is_connected:
            selected_port = self.combo_ports.currentText()
            try:
                self.ser = serial.Serial(selected_port, 115200, timeout=0)
                self.is_connected = True
                self.btn_connect.setText("Desconectar")
                self.btn_connect.setStyleSheet("background-color: #f8d7da; color: #721c24; font-weight: bold;")
                self.combo_ports.setEnabled(False)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"No se pudo abrir el puerto:\n{e}")
        else:
            if self.ser and self.ser.is_open:
                self.ser.close()
            self.is_connected = False
            self.btn_connect.setText("Conectar")
            self.btn_connect.setStyleSheet("background-color: #d4edda; color: #155724; font-weight: bold;")
            self.combo_ports.setEnabled(True)

    def change_filter_method(self, index):
        if self.is_connected and self.ser and self.ser.is_open:
            self.ser.write(f"FILTER:{index}\n".encode('utf-8'))

    def change_kalman_aggressiveness(self, value):
        r_val = value / 100.0
        if self.is_connected and self.ser and self.ser.is_open:
            self.ser.write(f"KALMAN_R:{r_val:.2f}\n".encode('utf-8'))

    def change_fir_aggressiveness(self, value):
        if self.is_connected and self.ser and self.ser.is_open:
            self.ser.write(f"FIR_W:{value}\n".encode('utf-8'))

    def update_data(self):
        if not self.is_connected or not self.ser or not self.ser.is_open:
            return
        try:
            lines = self.ser.readlines()
            for raw_line in lines:
                line = raw_line.decode('utf-8', errors='ignore').strip()
                if not line: continue
                parts = line.split(',')
                
                # Paquete Mano: H, 2, raw_x, raw_y, filt_x, filt_y
                if parts[0] == 'H' and len(parts) >= 6:
                    _, _, raw_x, raw_y, filt_x, filt_y = parts[:6]
                    rx, ry, fx, fy = float(raw_x), float(raw_y), float(filt_x), float(filt_y)

                    self.hand_x_raw[:-1] = self.hand_x_raw[1:]
                    self.hand_x_raw[-1] = rx
                    self.hand_x_filt[:-1] = self.hand_x_filt[1:]
                    self.hand_x_filt[-1] = fx

                    self.hand_y_raw[:-1] = self.hand_y_raw[1:]
                    self.hand_y_raw[-1] = ry
                    self.hand_y_filt[:-1] = self.hand_y_filt[1:]
                    self.hand_y_filt[-1] = fy

                    self.lbl_hx.setText(f"Hand X: {fx:.2f}°")
                    self.lbl_hy.setText(f"Hand Y: {fy:.2f}°")

                # Paquete Carro: C, 1, enc1, enc2, mpu_car_x, mpu_car_y, spd1, spd2
                elif parts[0] == 'C' and len(parts) >= 8:
                    _, _, enc1, enc2, mpu_x, mpu_y, spd1, spd2 = parts[:8]
                    e1, e2 = float(enc1), float(enc2)
                    mx, my = float(mpu_x), float(mpu_y)
                    s1, s2 = float(spd1), float(spd2)

                    # Simulación de filtrado leve para MPU del carro y motores en interfaz
                    self.car_mpu_x_raw[:-1] = self.car_mpu_x_raw[1:]
                    self.car_mpu_x_raw[-1] = mx
                    self.car_mpu_x_filt[:-1] = self.car_mpu_x_filt[1:]
                    self.car_mpu_x_filt[-1] = mx * 0.95 + (0.05 * self.car_mpu_x_raw[-2])

                    self.car_mpu_y_raw[:-1] = self.car_mpu_y_raw[1:]
                    self.car_mpu_y_raw[-1] = my
                    self.car_mpu_y_filt[:-1] = self.car_mpu_y_filt[1:]
                    self.car_mpu_y_filt[-1] = my * 0.95 + (0.05 * self.car_mpu_y_raw[-2])

                    self.m1_raw[:-1] = self.m1_raw[1:]
                    self.m1_raw[-1] = s1
                    self.m2_raw[:-1] = self.m2_raw[1:]
                    self.m2_raw[-1] = s2

                    self.enc1_vals[:-1] = self.enc1_vals[1:]
                    self.enc1_vals[-1] = e1
                    self.enc2_vals[:-1] = self.enc2_vals[1:]
                    self.enc2_vals[-1] = e2

                    self.lbl_cx.setText(f"Car X: {mx:.2f}°")
                    self.lbl_cy.setText(f"Car Y: {my:.2f}°")
                    self.lbl_enc.setText(f"Enc 1: {int(e1)} | Enc 2: {int(e2)}")

            # Refrescar Curvas en la interfaz
            self.curve_hx_raw.setData(self.hand_x_raw)
            self.curve_hx_filt.setData(self.hand_x_filt)
            self.curve_hy_raw.setData(self.hand_y_raw)
            self.curve_hy_filt.setData(self.hand_y_filt)
            
            self.curve_cx_raw.setData(self.car_mpu_x_raw)
            self.curve_cx_filt.setData(self.car_mpu_x_filt)
            self.curve_cy_raw.setData(self.car_mpu_y_raw)
            self.curve_cy_filt.setData(self.car_mpu_y_filt)
            
            self.curve_m1.setData(self.m1_raw)
            self.curve_m2.setData(self.m2_raw)
            self.curve_enc1.setData(self.enc1_vals)
            self.curve_enc2.setData(self.enc2_vals)

            self.curve_trajectory.setData(self.x_traj[-100:], self.y_traj[-100:])
        except:
            pass

    def export_to_excel(self):
        if not self.all_logged_data: return
        filename, _ = QFileDialog.getSaveFileName(self, "Guardar Excel", "", "Archivos Excel (*.xlsx)")
        if filename: pd.DataFrame(self.all_logged_data).to_excel(filename, index=False)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ControlStationApp()
    window.show()
    sys.exit(app.exec_())
