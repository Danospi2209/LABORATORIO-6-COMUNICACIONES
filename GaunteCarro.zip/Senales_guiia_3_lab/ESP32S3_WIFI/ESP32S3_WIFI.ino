#include <WiFi.h>
#include <WiFiUdp.h>
#include <ctype.h>
#include <strings.h>

// ================= Red =================
const char* ssid = "ESP32_Control_Network";
const char* password = "12345678password";

#define SERIAL_BAUD 115200   // si usas el USB nativo del S3 el valor no importa; con UART debe coincidir con Python

WiFiUDP udp;
unsigned int localPort = 4210;

IPAddress handIP(192, 168, 4, 2);
IPAddress carIP(192, 168, 4, 3);

// ================= Mecánica del carro (AJUSTA) =================
#define PULSES_REV 360.0f    // pulsos del canal A por vuelta de RUEDA (después de la reductora)
#define WHEEL_D_M  0.040f    // diámetro de rueda [m]
const float METROS_POR_PULSO = 3.14159265f * WHEEL_D_M / PULSES_REV;

// Telemetría del carro (mismo formato que envía el carro; long = 4 bytes en C3 y S3)
typedef struct __attribute__((packed)) {
    uint8_t device_id; // 1 = Car
    int32_t enc1;
    int32_t enc2;
    float mpu_car_x;
    float mpu_car_y;
    float motor_spd1;  // PWM aplicado (con signo)
    float motor_spd2;
} CarTelemetry;
static_assert(sizeof(CarTelemetry) == 25, "CarTelemetry debe medir 25 bytes igual que en el carro");

// ==== FILTROS ====
#define FIR_MAX 64

// FIR de coeficientes iguales: promedio móvil de las últimas W muestras (W mayor = más agresivo)
struct MediaMovil {
    float buf[FIR_MAX];
    int idx = 0, n = 0;
    float process(float x, int W) {
        W = constrain(W, 1, FIR_MAX);
        buf[idx] = x;
        idx = (idx + 1) % FIR_MAX;
        if (n < FIR_MAX) n++;
        int m = (n < W) ? n : W;
        float s = 0;
        int j = idx;
        for (int k = 0; k < m; k++) {
            j = (j - 1 + FIR_MAX) % FIR_MAX;
            s += buf[j];
        }
        return s / m;
    }
};

// Kalman de 2 estados (valor y derivada), dt variable. R = rBase * kr  (kr mayor = más agresivo)
struct Kalman {
    float x0 = 0, x1 = 0, P00 = 1, P01 = 0, P10 = 0, P11 = 1;
    bool listo = false;
    float q, rBase;
    Kalman(float q_, float r_) : q(q_), rBase(r_) {}
    float process(float z, float dt, float kr) {
        float r = rBase * kr;
        if (!listo) { x0 = z; x1 = 0; P00 = r; P01 = P10 = 0; P11 = 1; listo = true; return x0; }
        float dt2 = dt * dt, dt3 = dt2 * dt, dt4 = dt3 * dt;
        float x0p = x0 + dt * x1;
        float P00p = P00 + dt * (P10 + P01) + dt2 * P11 + q * dt4 / 4;
        float P01p = P01 + dt * P11 + q * dt3 / 2;
        float P10p = P10 + dt * P11 + q * dt3 / 2;
        float P11p = P11 + q * dt2;
        float S = P00p + r;
        float K0 = P00p / S, K1 = P10p / S;
        float y = z - x0p;
        x0 = x0p + K0 * y;
        x1 = x1 + K1 * y;
        P00 = (1.0f - K0) * P00p;
        P01 = (1.0f - K0) * P01p;
        P10 = P10p - K1 * P00p;
        P11 = P11p - K1 * P01p;
        return x0;
    }
    float rate() const { return x1; }
};

// Ajustes que manda la interfaz
int filtroActivo = 2;      // 0 = sin filtro, 1 = FIR, 2 = Kalman
int firW = 8;              // FIR: ventana (1..64)
float kalmanR = 1.0f;      // Kalman: multiplicador de R (1 = normal, >1 más suave, <1 más rápido)

// Estado del procesamiento del carro
float pos[2] = {0, 0}, posPrev[2] = {0, 0};
int32_t encPrev[2] = {0, 0};
bool primerPaquete = true;
uint32_t tPrevUs = 0;
Kalman kPos[2] = {Kalman(1.0f, 1e-6f), Kalman(1.0f, 1e-6f)};    // posición [m] -> posición y velocidad
Kalman kAng[2] = {Kalman(2000.0f, 4.0f), Kalman(2000.0f, 4.0f)}; // ángulos MPU [grados]
MediaMovil fPos[2], fVel[2], fAng[2];
// ==== FIN FILTROS ====

void reiniciarProcesamiento() {
    pos[0] = pos[1] = posPrev[0] = posPrev[1] = 0;
    primerPaquete = true;
    for (int i = 0; i < 2; i++) {
        kPos[i] = Kalman(1.0f, 1e-6f);
        kAng[i] = Kalman(2000.0f, 4.0f);
        fPos[i] = MediaMovil(); fVel[i] = MediaMovil(); fAng[i] = MediaMovil();
    }
}

void procesarYEnviarCarro(const CarTelemetry &c) {
    // 1) Línea original (sin filtrar), igual que antes
    Serial.printf("C,%d,%ld,%ld,%.2f,%.2f,%.2f,%.2f\n", c.device_id, (long)c.enc1, (long)c.enc2,
                  c.mpu_car_x, c.mpu_car_y, c.motor_spd1, c.motor_spd2);

    // 2) Tiempo entre paquetes
    uint32_t ahora = micros();
    float dt = (ahora - tPrevUs) / 1e6f;
    tPrevUs = ahora;
    int32_t enc[2] = {c.enc1, c.enc2};
    float spd[2] = {c.motor_spd1, c.motor_spd2};
    if (primerPaquete || dt > 0.5f) {          // primer dato o hueco largo: solo sincronizar
        for (int i = 0; i < 2; i++) encPrev[i] = enc[i];
        primerPaquete = false;
        return;
    }
    dt = constrain(dt, 0.005f, 0.5f);

    float posRaw[2], velRaw[2], posF[2], velF[2], ang[2] = {c.mpu_car_x, c.mpu_car_y}, angF[2];
    for (int i = 0; i < 2; i++) {
        // Posición lineal: pulsos -> metros; el sentido sale del signo del PWM aplicado (solo hay canal A)
        int32_t d = enc[i] - encPrev[i];
        encPrev[i] = enc[i];
        if (d < 0) d = 0;                      // el carro se reinició: ignorar
        pos[i] += (spd[i] < 0 ? -1.0f : 1.0f) * d * METROS_POR_PULSO;
        posRaw[i] = pos[i];
        velRaw[i] = (pos[i] - posPrev[i]) / dt;
        posPrev[i] = pos[i];

        // Se calculan siempre los dos filtros (así el cambio de método es inmediato)
        float posK = kPos[i].process(pos[i], dt, kalmanR);
        float velK = kPos[i].rate();
        float posA = fPos[i].process(pos[i], firW);
        float velA = fVel[i].process(velRaw[i], firW);
        float angK = kAng[i].process(ang[i], dt, kalmanR);
        float angA = fAng[i].process(ang[i], firW);

        if (filtroActivo == 2)       { posF[i] = posK; velF[i] = velK; angF[i] = angK; }
        else if (filtroActivo == 1) { posF[i] = posA; velF[i] = velA; angF[i] = angA; }
        else                        { posF[i] = posRaw[i]; velF[i] = velRaw[i]; angF[i] = ang[i]; }
    }

    // 3) Línea procesada:
    Serial.printf("D,%lu,%d,%d,%.3f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%.2f,%.2f\n",
                  (unsigned long)millis(), filtroActivo, firW, kalmanR,
                  posRaw[0], posRaw[1], velRaw[0], velRaw[1],
                  posF[0], posF[1], velF[0], velF[1],
                  ang[0], ang[1], angF[0], angF[1]);
}

// ================= UDP =================
void descartarPaquete(int n) {
    uint8_t basura[64];
    while (n > 0) {
        int r = udp.read(basura, sizeof(basura));
        if (r <= 0) break;
        n -= r;
    }
}

void leerUDP() {
    static char texto[256];
    for (int k = 0; k < 20; k++) {                     // vaciar los paquetes pendientes
        int size = udp.parsePacket();
        if (size <= 0) break;
        IPAddress ip = udp.remoteIP();

        if (ip == carIP) {                             // carro: binario
            if (size == (int)sizeof(CarTelemetry)) {
                CarTelemetry c;
                udp.read((uint8_t*)&c, sizeof(c));
                procesarYEnviarCarro(c);
            } else {
                descartarPaquete(size);
            }
        } else if (ip == handIP) {                     // mano: texto CSV, se reenvía tal cual
            int len = udp.read((uint8_t*)texto, sizeof(texto) - 2);
            if (len > 0) {
                if (size > len) descartarPaquete(size - len);
                texto[len] = '\0';
                Serial.print(texto);
                if (texto[len - 1] != '\n') Serial.print('\n');
            }
        } else {
            descartarPaquete(size);
        }
    }
}

// ================= Comandos desde Python =================
void enviarAMano(const char* prefijo, const char* valor) {
    udp.beginPacket(handIP, localPort);
    udp.print(prefijo);
    udp.print(valor);
    udp.endPacket();
}

int parseFiltro(const char* v) {
    while (*v == ' ') v++;
    if (isdigit((unsigned char)*v)) return constrain(atoi(v), 0, 2);
    if (strncasecmp(v, "KAL", 3) == 0) return 2;
    if (strncasecmp(v, "FIR", 3) == 0) return 1;
    return 0;                                       // NONE / RAW / cualquier otro
}

void manejarComando(char* cmd) {
    if (strncmp(cmd, "FILTER:", 7) == 0) {
        filtroActivo = parseFiltro(cmd + 7);
        enviarAMano("F:", cmd + 7);
    } else if (strncmp(cmd, "KALMAN_R:", 9) == 0) {
        kalmanR = constrain(atof(cmd + 9), 0.001f, 10000.0f);
        enviarAMano("KR:", cmd + 9);
    } else if (strncmp(cmd, "FIR_W:", 6) == 0) {
        firW = constrain(atoi(cmd + 6), 1, FIR_MAX);
        enviarAMano("FW:", cmd + 6);
    } else if (strcmp(cmd, "ZERO") == 0) {              // poner la posición en 0 y reiniciar filtros
        reiniciarProcesamiento();
    }
}

void leerSerial() {
    static char linea[64];
    static uint8_t n = 0;
    while (Serial.available() > 0) {                 // sin bloqueos (antes: readStringUntil)
        char ch = Serial.read();
        if (ch == '\n') {
            linea[n] = '\0';
            if (n > 0) manejarComando(linea);
            n = 0;
        } else if (ch != '\r' && n < sizeof(linea) - 1) {
            linea[n++] = ch;
        }
    }
}

void setup() {
    Serial.begin(SERIAL_BAUD);
    delay(1000);
    WiFi.softAP(ssid, password);
    Serial.print("# Gateway S3 AP creado. IP: ");
    Serial.println(WiFi.softAPIP());
    udp.begin(localPort);
    reiniciarProcesamiento();
}

void loop() {
    leerUDP();
    leerSerial();
}